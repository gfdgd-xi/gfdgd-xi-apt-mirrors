#!/bin/sh -e

PREREQ=""

# Output pre-requisites
prereqs()
{
        echo "$PREREQ"
}

case "$1" in
    prereqs)
        prereqs
#        exit 0
        ;;
esac


if  [ "$(echo ${LIVE_BOOT_CMDLINE} | grep -c boot=live)" -ne "0" ];
then
        mount -n -t securityfs securityfs /sys/kernel/security
        #规避系统进入备份还原后,备份速度慢问题
        echo "dont_measure func=MMAP_CHECK mask=MAY_EXEC"  > /sys/kernel/security/integrity/ima/policy
        exit 1
fi

if [ "$(grep -c ima_appraise=off /proc/cmdline)" -ne "0" ];
then
        exit 1
fi

mount -n -t securityfs securityfs /sys/kernel/security
grep -v "^#" /usr/share/deepin-ima-daemon/policy.conf > /sys/kernel/security/integrity/ima/policy
