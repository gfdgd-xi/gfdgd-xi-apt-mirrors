#!/bin/sh

echo "Adding IMA binaries"

. /usr/share/initramfs-tools/hook-functions

#copy_exec /etc/keys/x509_evm.der
#copy_exec /etc/keys/x509_ima.der
if [ -e "/usr/share/deepin-ima-daemon/policy.conf" ]; then
    copy_exec /usr/share/deepin-ima-daemon/policy.conf /usr/share/deepin-ima-daemon/policy.conf
fi
#copy_exec /bin/keyctl /bin/keyctl
if [ -e "/usr/bin/evmctl" ]; then
    copy_exec /usr/bin/evmctl /bin/evmctl
fi
