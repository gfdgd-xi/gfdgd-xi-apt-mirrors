#!/bin/bash
XDG_CURRENT_DESKTOP="Deepin"
$1 -platformtheme deepin "$@"
