#!/bin/bash
nic=$1
if curl www.baidu.com --interface $nic --max-time 2 &>/dev/null
then
	echo "online"
else
	echo "offline"
fi
