#include <linux/version.h>
#include <linux/fs.h>
#include <linux/buffer_head.h>
#include <linux/limits.h>
#include <linux/file.h>
#include <linux/list.h>
#include <linux/limits.h>
#include <linux/slab.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
#include <linux/sched/signal.h>
#else
#include <linux/sched.h>
#endif
#include <linux/miscdevice.h>
#include <linux/random.h>
#include <linux/types.h>
#include <linux/ioctl.h>
#include <linux/lsm_uos_hook_manager.h>
#include "chdev.h"

#define UOS_HOOK_NAME_MAX_LEN 50
#define UOS_HOOKID_NAME_STATUS(hook_id)  \
	{ hook_id, 0, #hook_id },
#define UOS_HOOKID_NAME_STATUS_END  UOS_HOOKID_NAME_STATUS(UOS_HOOK_NONE)

struct uos_res_ioc_args {
	u8 hookid;
	u8 hook_status;
	char hook_name[UOS_HOOK_NAME_MAX_LEN];
};

#define UOSRES_IOC_MAGIC  'M'
#define UOSRES_IOC_HOOK_GETSTATUS _IOR(UOSRES_IOC_MAGIC, 0, struct uos_res_ioc_args)
#define UOSRES_IOC_HOOK_ENABLE _IOW(UOSRES_IOC_MAGIC, 1, struct uos_res_ioc_args)

#define UOS_HOOK_NUM 200
#define DEV_NAME	"uos_resources"
#define MAX_UUID_LEN 20 // u32 max(4294967295 ~ 2^32−1) + msg type(2)
			// + pid max(32768 ~ /proc/sys/kernel/pid_max)
			// + '-' + 1 + align(4)
typedef struct uos_resource_request_t {
	pid_t pid;
	int result;
	struct list_head entry;
	char message[0];
} uos_resource_request;

static struct uos_resource_dev_t {
	struct miscdevice misc;
	pid_t controller;
	struct mutex lock;
	struct list_head head;
	wait_queue_head_t response_wq;
	wait_queue_head_t request_wq;
} uos_resource_dev;

typedef struct __uos_hook_status__ {
	u8 hookid;
	u8 hook_status;  // 0 means no hook for hookid, or else do hook 
	const char *name;
} uos_hook_status;

static uos_hook_status uos_hook_status_table[UOS_HOOK_NUM] = {
	UOS_HOOKID_NAME_STATUS(UOS_SOCKET_CREATE)
	UOS_HOOKID_NAME_STATUS(UOS_SOCKET_LISTEN)
	UOS_HOOKID_NAME_STATUS(UOS_INODE_MKNOD)
	UOS_HOOKID_NAME_STATUS_END
};

static struct __uos_res_hook_enable_ctrl_ {
	rwlock_t rw_lock;
	uos_hook_status *hookname_table;
	u8 hookname_table_size;
} uos_res_hook_ctrl;

int _dev_init = 0;


int get_uos_hook_status_by_id(int hookid)
{
	int ret = 0;
	read_lock(&uos_res_hook_ctrl.rw_lock);
	for (int i = 0; i < uos_res_hook_ctrl.hookname_table_size; ++i) {
		if (uos_res_hook_ctrl.hookname_table[i].hookid == hookid) {
			ret = uos_res_hook_ctrl.hookname_table[i].hook_status;
		}
	}
	read_unlock(&uos_res_hook_ctrl.rw_lock);
	return ret;
}

static u8 get_uos_hook_status_table_size(void) 
{
	int count = 0;
	read_lock(&uos_res_hook_ctrl.rw_lock);
	for (u8 i = 0; i < UOS_HOOK_NUM; ++i) {
		if (uos_res_hook_ctrl.hookname_table[i].hookid != UOS_HOOK_NONE) {
			++count;
		}
	}
	read_unlock(&uos_res_hook_ctrl.rw_lock);
	return count;
}

static u8 get_uos_hookid_by_name(const char* hookname)
{
	if (!hookname) {
		return UOS_HOOK_NONE;
	}
	u8 id = UOS_HOOK_NONE;
	read_lock(&uos_res_hook_ctrl.rw_lock);
	int hook_nr = uos_res_hook_ctrl.hookname_table_size ? uos_res_hook_ctrl.hookname_table_size : UOS_HOOK_NUM;
	for (int i = 0; i < hook_nr; ++i) {
		if (strncmp(hookname, uos_res_hook_ctrl.hookname_table[i].name, UOS_HOOK_NAME_MAX_LEN) == 0) {
			id = uos_res_hook_ctrl.hookname_table[i].hookid;
			break;
		}
	}
	read_unlock(&uos_res_hook_ctrl.rw_lock);
	return id;
}

static u8 get_uos_hook_status_by_name(const char* hookname) 
{
	if (!hookname) {
		return 0;
	}
	int id = UOS_HOOK_NONE;
	read_lock(&uos_res_hook_ctrl.rw_lock);
	int hook_nr = uos_res_hook_ctrl.hookname_table_size ? uos_res_hook_ctrl.hookname_table_size : UOS_HOOK_NUM;
	for (int i = 0; i < hook_nr; ++i) {
		if (strncmp(hookname, uos_res_hook_ctrl.hookname_table[i].name, UOS_HOOK_NAME_MAX_LEN) == 0) {
			id = uos_res_hook_ctrl.hookname_table[i].hook_status;
			break;
		}
	}
	read_unlock(&uos_res_hook_ctrl.rw_lock);
	return 0;
}


static long misc_dev_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	//uos_hook_status *argp = (uos_hook_status __user *)arg;
	long ret = 0;
	struct uos_res_ioc_args *argp = kzalloc(sizeof(struct uos_res_ioc_args), GFP_KERNEL);
	if (argp == NULL) {
		return -ENOMEM;
	}

	if (copy_from_user(argp, (void*)arg, sizeof(struct uos_res_ioc_args)) !=0) {
		ret = -EFAULT;
		goto out;
	}

	switch (cmd) {
		case UOSRES_IOC_HOOK_GETSTATUS:
			{
				argp->hook_status = get_uos_hook_status_by_name(argp->hook_name);
				argp->hookid = get_uos_hookid_by_name(argp->hook_name);
				if (copy_to_user((void*)arg, argp, sizeof(struct uos_res_ioc_args))) {
					ret = -EFAULT;
					goto out;
				}
			}
				
			break;
		case UOSRES_IOC_HOOK_ENABLE:
			{
				write_lock(&uos_res_hook_ctrl.rw_lock);
				for (int i = 0; i < uos_res_hook_ctrl.hookname_table_size; ++i) {
					if (strncmp(argp->hook_name, uos_res_hook_ctrl.hookname_table[i].name, UOS_HOOK_NAME_MAX_LEN)) {
						continue;
					} 
					uos_res_hook_ctrl.hookname_table[i].hook_status = argp->hook_status;
					write_unlock(&uos_res_hook_ctrl.rw_lock);
					goto out;
					
					
				}
				write_unlock(&uos_res_hook_ctrl.rw_lock);
				ret = -EINVAL; // hookname is not an entry of table.
				goto out;
			}
			break;
		default:
			ret = -EFAULT;
			break;
	}

out:
	kfree(argp);
	return ret;
}

static void reset_requests_result_locked(void)
{
	uos_resource_request *req = NULL;

	mutex_lock(&uos_resource_dev.lock);
	list_for_each_entry(req, &uos_resource_dev.head, entry) {
		if (req->result == UOS_RES_CTRL_RET_WAIT)
			req->result = UOS_RES_CTRL_RET_UNKNOWN;
	}
	mutex_unlock(&uos_resource_dev.lock);
}

static int misc_dev_open(struct inode* si, struct file* filp)
{
	if (uos_resource_dev.controller)
		return -EACCES;

	uos_resource_dev.controller = current->pid;
	reset_requests_result_locked();
	return 0;
}

static int misc_dev_release(struct inode* si, struct file* filp)
{
	uos_resource_dev.controller = 0;
	return 0;
}

static int read_requests_locked(int* total, char* kbuf, size_t size)
{
	uos_resource_request* req;
	char *p = kbuf;
	mutex_lock(&uos_resource_dev.lock);
	list_for_each_entry(req, &uos_resource_dev.head, entry) {
		if (req->result != UOS_RES_CTRL_RET_UNKNOWN)
			continue;

		*total = (*total) + 1;
		if (strlen(req->message) + 1 + p > kbuf + size)
			break;
		strcpy(p, req->message);
		req->result = UOS_RES_CTRL_RET_WAIT;
		p += strlen(p) + 1;
	}
	mutex_unlock(&uos_resource_dev.lock);
	return p - kbuf;
}

static ssize_t misc_dev_read(struct file* filp, char __user* buf, size_t size, loff_t* offset)
{
	DECLARE_WAITQUEUE(wait, current);
	char *kbuf = NULL;
	int n = 0;
int total = 0;

	if (size <= 1)
		return -EINVAL;

	kbuf = kzalloc(size, GFP_KERNEL);
	if (unlikely(kbuf == 0))
		return -ENOSPC;

	add_wait_queue(&uos_resource_dev.request_wq, &wait);

	for (;;) {
		total = 0;
		n = read_requests_locked(&total, kbuf, size);
		if (n) // data read out
			break;

		if (total == 0) { // no data
			if (filp->f_flags & O_NONBLOCK) {
				n = -EAGAIN;
				goto readout;
			}

			__set_current_state(TASK_INTERRUPTIBLE);
			//TODO: better to move unlock here (quite some code needs modification then)
			schedule();
		} else if (n == 0) { // has data but buf too small
			n = 0;
			goto readout;
		}

		if (signal_pending(current)) {
			n = -EINTR;
			goto readout;
		}
	}

	if (copy_to_user(buf, kbuf, n))
		n = -EFAULT;

readout:
	remove_wait_queue(&uos_resource_dev.request_wq, &wait);
	set_current_state(TASK_RUNNING);
	kfree(kbuf);
	return n;
}

//test: echo -e -n "\x00/media/sf_D_DRIVE/raphael/temp/kernel-enh/mylib.so\x00" > /dev/elf_verifier
static ssize_t misc_dev_write(struct file* filp, const char __user* buf, size_t size, loff_t* offset)
{
	uos_resource_request* req = NULL;
	char *kbuf = NULL;
	char *p = NULL;
	int resp_cnt = 0;  // 响应消息计数

	if (size <= sizeof(unsigned char) + 1)
		return -EINVAL;

	kbuf = kzalloc(size, GFP_KERNEL);
	if (unlikely(kbuf == 0))
		return -ENOSPC;

	if (copy_from_user(kbuf, buf, size)) {
		kfree(kbuf);
		return -EFAULT;
	}

	if (kbuf[size-1] != 0) {
		kfree(kbuf);
		return -EINVAL;
	}

	p = kbuf;
	mutex_lock(&uos_resource_dev.lock);
	while (p < kbuf + size) {
		unsigned char result = *(unsigned char*)p;  // response result overwrite the fire byte of a message entity.
		p++;
		//printk("==%d\n", result);
		if (result < UOS_RES_CTRL_RET_OK || result >= UOS_RES_CTRL_RET_UNKNOWN) {
			p += strlen(p) + 1;  // pointer to next message response
			continue;
		}

		list_for_each_entry(req, &uos_resource_dev.head, entry) {
			// request doesnot handle, next message entity in turn.
			if (strcmp(req->message, p) || req->result < UOS_RES_CTRL_RET_WAIT)
				continue;

			// request has been handled, update the response result.
			req->result = result;
			resp_cnt++;  
		}
		p += strlen(p) + 1;
	}
	mutex_unlock(&uos_resource_dev.lock);
	
	//printk("total: %d\n", total);
	kfree(kbuf);
	if (resp_cnt)
		wake_up_interruptible(&uos_resource_dev.response_wq);
	return size;
}

static struct file_operations misc_dev_fops = {
	.owner = THIS_MODULE,
	.open = misc_dev_open,
	.read = misc_dev_read,
	.write = misc_dev_write,
	.release = misc_dev_release,
	.unlocked_ioctl = misc_dev_ioctl,
};

static uos_resource_request* create_uos_resource_req(const int msg_type, const char* target)
{
	int path_size = 0;
	char uuid[MAX_UUID_LEN] = {0};
	uos_resource_request *req = NULL;

	memset(uuid, 0, MAX_UUID_LEN);
	snprintf(uuid, MAX_UUID_LEN, "%d-%u-", msg_type, get_random_u32());
	path_size = strlen(uuid);
	if (target) {
		path_size += strlen(target);
	}
	req = kzalloc(sizeof(uos_resource_request) + path_size + 1, GFP_KERNEL);

	if (unlikely(req == 0))
		return 0;

	req->pid = current->pid;
	strcpy(req->message, uuid);
	if (target){
	       strcat(req->message, target);
	}
	req->result = UOS_RES_CTRL_RET_UNKNOWN;

	mutex_lock(&uos_resource_dev.lock);
	list_add_tail(&req->entry, &uos_resource_dev.head);
	mutex_unlock(&uos_resource_dev.lock);
	return req;
}

static void clean_requests_locked(pid_t pid)
{
	struct list_head *p = NULL, *next = NULL;
	uos_resource_request *req = NULL;

	mutex_lock(&uos_resource_dev.lock);
	list_for_each_safe(p, next, &uos_resource_dev.head) {
		req = list_entry(p, uos_resource_request, entry);
		if (req->pid != pid)
			continue;

		list_del(p);
		kfree(req);
	}
	mutex_unlock(&uos_resource_dev.lock);
}

static int get_response_nolock(const uos_resource_request* evr)
{
	struct list_head *p = NULL, *next = NULL;
	uos_resource_request *req = NULL;
	int ret = 0;

	list_for_each_safe(p, next, &uos_resource_dev.head) {
		req = list_entry(p, uos_resource_request, entry);
		if (strcmp(req->message, evr->message) || req->result >= UOS_RES_CTRL_RET_WAIT)
			continue;

		ret = req->result;
		list_del(p);
		kfree(req);
		return ret;
	}
	return UOS_RES_CTRL_RET_UNKNOWN;
}

int access_verify(int msg_type, const char* target)
{
	DECLARE_WAITQUEUE(wait, current);
	uos_resource_request *req = NULL;
	int ret = 0;

	req = create_uos_resource_req(msg_type, target);
	if (req == 0)
		return UOS_RES_CTRL_RET_NOMEM;

	add_wait_queue(&uos_resource_dev.response_wq, &wait);
	wake_up_interruptible(&uos_resource_dev.request_wq);

	ret = UOS_RES_CTRL_RET_UNKNOWN;
	mutex_lock(&uos_resource_dev.lock);
	for (;;) {
		// Must 'get_response_nolock' firstly, otherwise
		// sometimes it will be not run because of no wake up event.
		// Wake up event should be send after write which has
		// item changed, sometimes the event was sent too early.
		ret = get_response_nolock(req);
		if (ret != UOS_RES_CTRL_RET_UNKNOWN)
			break;

		__set_current_state(TASK_INTERRUPTIBLE);
		mutex_unlock(&uos_resource_dev.lock);
		schedule();

		if (signal_pending(current)) {
			clean_requests_locked(req->pid);
			ret = UOS_RES_CTRL_RET_INTR;
			goto out;
		}

		mutex_lock(&uos_resource_dev.lock);
	}

	mutex_unlock(&uos_resource_dev.lock);
out:
	remove_wait_queue(&uos_resource_dev.response_wq, &wait);
	set_current_state(TASK_RUNNING);
	return ret;
}

int register_uos_resource_dev(void)
{
	int error = 0;

	if (_dev_init != 0) {
		return 0;
	}
	_dev_init = 1;

	uos_res_hook_ctrl.hookname_table =(uos_hook_status*)&uos_hook_status_table;
	rwlock_init(&uos_res_hook_ctrl.rw_lock);
	uos_res_hook_ctrl.hookname_table_size = get_uos_hook_status_table_size();
	uos_resource_dev.misc.minor = MISC_DYNAMIC_MINOR;
	uos_resource_dev.misc.name = DEV_NAME;
	uos_resource_dev.misc.fops = &misc_dev_fops;
	uos_resource_dev.controller = 0;
	mutex_init(&uos_resource_dev.lock);
	INIT_LIST_HEAD(&uos_resource_dev.head);
	init_waitqueue_head(&uos_resource_dev.response_wq);
	init_waitqueue_head(&uos_resource_dev.request_wq);
	error = misc_register(&uos_resource_dev.misc);
	if (!error)
		_dev_init = 2;
	else
		_dev_init = 0;
	return error;
}

void unregister_uos_resource_dev(void)
{
	misc_deregister(&uos_resource_dev.misc);
}
