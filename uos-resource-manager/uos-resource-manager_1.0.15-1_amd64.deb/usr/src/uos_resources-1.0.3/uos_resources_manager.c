#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/net.h>
#include <linux/socket.h>
#include <linux/netlink.h>
#include <net/sock.h>
#include <linux/lsm_uos_hook_manager.h>
//#include <linux/limits.h>
#include <linux/usb.h>
#include <linux/usb/hcd.h>
#include <linux/device.h>
#include "chdev.h"



#define MODULE_NAME "uos_resources"
#define MAX_PID_LEN 8

typedef struct uos_res_ctrl_hook_entry {
	int hook_id;
	struct uos_hook_cb_entry cb;
} uos_res_ctrl_hook_entry;

#define UOS_RES_CTRL_HOOK_ENTRY(id, hook_func, hook_ret_type, hook_args)  \
	{                                          \
		.hook_id = id,                     \
		.cb = {                            \
			.owner    = MODULE_NAME,   \
			.cb_addr  = (unsigned long)hook_func,     \
			.ret_type = hook_ret_type, \
			.arg_len  = hook_args,     \
		},				   \
	},			

#define UOS_RES_CTRL_HOOK_ENTRY_END \
	{ .hook_id = UOS_HOOK_NONE, }, \

int uos_res_ctrl_socket_create(int family, int type, int protocol, int kern)
{
	if (get_uos_hook_status_by_id(UOS_SOCKET_CREATE) == 0) {
		return 0;
	}
	if (kern)
		return 0;
	if (family != AF_INET && family != AF_INET6)
		return 0;

	if (type != SOCK_STREAM && type != SOCK_DGRAM)
		return 0;

	char pid_str[MAX_PID_LEN] = {0};
	snprintf(pid_str, MAX_PID_LEN, "%d", current->pid);
	if (access_verify(MSG_TYPE_SOCK_CREATE, pid_str)) {
		printk("verify failed.\n");
		return -1;
	}
	return 0;
}

int uos_res_ctrl_socket_listen(struct socket *sock, int backlog)
{
	if (get_uos_hook_status_by_id(UOS_SOCKET_LISTEN) == 0) {
		return 0;
	}

	if (!sock ||  !sock->sk)
		return 0;

	if (sock->type != -1 && sock->type != SOCK_STREAM && sock->type != SOCK_DGRAM)
		return 0;

	char pid_str[MAX_PID_LEN] = {0};
	snprintf(pid_str, MAX_PID_LEN, "%d", current->pid);
	if (access_verify(MSG_TYPE_SOCK_LISTEN, pid_str)) {
		printk("verify failed.\n");
		return -1;
	}
	return 0;
}

static int package_message_for_usb_device(const struct usb_device *udev, char** message)
{
	char *buffer = NULL;
	if (udev == NULL) {
		return 0;
	}
	const char *product_title = "Product:";
	size_t product_title_len =  strlen(product_title);
	const char *manufacturer_title = "Manufacturer:";
	size_t manufacturer_title_len = strlen(manufacturer_title);
	const char *serial_title = "SerialNumber:";
	size_t serial_title_len = strlen(serial_title);
	int msg_len = 0; 
	if (udev->product) {
		msg_len += product_title_len;
		msg_len += strlen(udev->product);
		msg_len += 1;
	}
	if (udev->manufacturer) {
		msg_len += manufacturer_title_len;
		msg_len += strlen(udev->manufacturer);
		msg_len += 1;
	}	
	if (udev->serial) {
		msg_len += serial_title_len;
		msg_len += strlen(udev->serial);
		msg_len += 1;
	}	
	msg_len += 1;
	msg_len += sizeof(pid_t);
	
	char pid_str[MAX_PID_LEN] = {0};
	sprintf(pid_str, "%d", current->pid);
	msg_len += strlen(pid_str);
	buffer = kzalloc(msg_len + 1, GFP_KERNEL);	

	if (buffer == NULL) {
		pr_err("%s, %d: no enough memory for message", __func__, __LINE__);
		return 0;
	}
	size_t offset = 0;
	if (udev->product) {
		memcpy(buffer + offset, product_title, product_title_len);
		offset += product_title_len;
		size_t product_len = strlen(udev->product);
		memcpy(buffer + offset, udev->product, product_len);
		offset += product_len;
		buffer[offset] = '\n';
		offset += 1;
	}
	if (udev->manufacturer) {
		memcpy(buffer + offset, manufacturer_title, manufacturer_title_len);
		offset += manufacturer_title_len;
		size_t manufacturer_len = strlen(udev->manufacturer);
		memcpy(buffer + offset, udev->manufacturer, manufacturer_len);
		offset += manufacturer_len;
		buffer[offset] = '\n';
		offset += 1;
	}
	if (udev->serial) {
		memcpy(buffer + offset, serial_title, serial_title_len);
		offset += serial_title_len;
		size_t serial_len = strlen(udev->serial);
		memcpy(buffer + offset, udev->serial, serial_len);
		offset += serial_len;
		buffer[offset] = '\n';
		offset += 1;
	}
	buffer[offset] = '-';
	offset += 1;
	memcpy(buffer + offset, pid_str, strlen(pid_str));
	*message = buffer;
	return 1;

}

static int lookup_usb_device(struct usb_device *udev, void *devnum)
{
	if (udev->dev.devt != *(dev_t *)devnum) {
		return 0;
	}
	char *message = NULL;
	if(!package_message_for_usb_device(udev, &message)) {
		pr_err("package_usb_device_msg failed!");
		return -1;
	}
	if (access_verify(MSG_TYPE_LOAD_USB_DRV, message)) {
		pr_err("pass usb device info to userspace failed!");	
		kfree(message);
		usb_set_device_state(udev,USB_STATE_NOTATTACHED);
		return -1;
	}
	kfree(message);
	return 0;

}

int uos_res_ctrl_inode_mknod(struct inode *dir, struct dentry *entry, umode_t mode, dev_t dev)
{
	if (get_uos_hook_status_by_id(UOS_INODE_MKNOD) == 0) {
		return 0;
	}
	int ret = 0;
	if (MAJOR(dev) == USB_DEVICE_MAJOR) {
		pr_info("lookup_usb_devie");
		ret = usb_for_each_dev(&dev, lookup_usb_device);
	}
	return ret;
}


static uos_res_ctrl_hook_entry entries[] = {
	UOS_RES_CTRL_HOOK_ENTRY(UOS_SOCKET_CREATE, uos_res_ctrl_socket_create, UOS_HOOK_RET_TY_INT, 4)
	UOS_RES_CTRL_HOOK_ENTRY(UOS_SOCKET_LISTEN, uos_res_ctrl_socket_listen, UOS_HOOK_RET_TY_INT, 2)
	UOS_RES_CTRL_HOOK_ENTRY(UOS_INODE_MKNOD, uos_res_ctrl_inode_mknod, UOS_HOOK_RET_TY_INT, 4)
	UOS_RES_CTRL_HOOK_ENTRY_END
};


int uos_res_ctrl_register_hook(void)
{
	int i = 0;
	int error = 0;

	for (; entries[i].hook_id != UOS_HOOK_NONE; i++) {
		error = uos_hook_register(entries[i].hook_id, &entries[i].cb);
		if (error) {
			printk("Failed to register hook %d, hook_id = %d\n", i, entries[i].hook_id);
			break;
		}
	}

	if (entries[i].hook_id == UOS_HOOK_NONE)
		return 0;

	return -1;
}

void uos_res_ctrl_cancel_hook(void)
{
	int i = 0;
	int error = 0;

	for (; entries[i].hook_id != UOS_HOOK_NONE; i++) {
		error = uos_hook_cancel(entries[i].hook_id, entries[i].cb.owner);
		if (error)
			printk("Failed to cancel hook %d, hook_id = %d\n", i, entries[i].hook_id);
        }
}

int __init init_module(void)
{
	int error = 0;

#ifdef CONFIG_SECURITY_NETWORK
	printk("network is defined\n");
#endif

	pr_info("start to init uos hook demo\n");
	error = uos_res_ctrl_register_hook();
	if (error) {
		pr_info("failed to registe hook\n");
		return -1;
	}

    	error = register_uos_resource_dev();
    	if (error) {
        	printk("has error: %d\n", error);
    	}
	
        pr_info("finish to init uos hook demo\n");
	return 0;
}

void __exit cleanup_module(void)
{
	uos_res_ctrl_cancel_hook();
	unregister_uos_resource_dev();
	pr_info("exit the uos hook demo\n");
}

MODULE_LICENSE("GPL");
MODULE_AUTHOR("jouyouyun");
MODULE_DESCRIPTION("The module for uos resources manager");


