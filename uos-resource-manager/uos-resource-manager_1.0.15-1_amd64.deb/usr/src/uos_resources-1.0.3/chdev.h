#pragma once

enum retcode_uos_res_ctrl {
	UOS_RES_CTRL_RET_OK = 0,
	UOS_RES_CTRL_RET_FAIL = 1,
	UOS_RES_CTRL_RET_NOMEM = 2,
	UOS_RES_CTRL_RET_INTR = 3,
	UOS_RES_CTRL_RET_WAIT = 4,
	UOS_RES_CTRL_RET_UNKNOWN = 5,
};

enum uos_res_msg_type {
	MSG_TYPE_SOCK_CREATE = 91,
	MSG_TYPE_SOCK_LISTEN = 92,
	MSG_TYPE_LOAD_USB_DRV = 93,
	MSG_TYPE_MAX,
};


int get_uos_hook_status_by_id(int hookid);
int access_verify(int msg_type, const char* target);
int register_uos_resource_dev(void);
void unregister_uos_resource_dev(void);
